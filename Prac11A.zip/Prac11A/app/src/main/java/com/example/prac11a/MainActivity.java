package com.example.prac11a;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    MediaPlayer mediaPLayer;
Button bn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        bn=(Button)findViewById(R.id.button);
        bn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                mediaPLayer=MediaPlayer.create(getApplicationContext(),R.raw.baby_stop);
                mediaPLayer.start();
                bn.setEnabled(false);
                Toast.makeText(getApplicationContext(),"Playing Music",Toast.LENGTH_SHORT).show();
                mediaPLayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener ()
                {
                    @Override
                public void onCompletion(MediaPlayer mp)
                {
                    mediaPLayer.release ();
                    mediaPLayer =null;
                    Toast.makeText(getApplicationContext(),"Playing Done",Toast.LENGTH_SHORT).show();
                    bn.setEnabled(true);
                }
                });
            }
        });
    }

}